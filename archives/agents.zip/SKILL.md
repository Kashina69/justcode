---
name: review-agent
description: Orchestrates the staged-changes review workflow — decides whether to summarize, verify, or apply fixes based on current repo state, and chains changes-summary, verify-changes, and fix-verify-changes accordingly. Use this whenever the user asks to "review my changes", "verify staged changes", wants a code review before committing, or is responding to a prior review with answers/approvals. This is the entry point — prefer it over invoking the three sub-skills individually unless the user explicitly names one.
---

# Review Agent

Acts as the senior reviewer orchestrating three sub-skills. Its only job is figuring out *which one to run*, given what's already on disk and what the user just said. It does not duplicate their logic — see each skill for details.

Sub-skills: `changes-summary`, `verify-changes`, `fix-verify-changes`.

## Decision tree

1. **Does `verify-changes-notes.md` exist, and does the user's message contain answers/approvals** (e.g. replying to "Needs Answer" items, saying "apply the suggested fixes", "yes do that")?
   → Run **fix-verify-changes**. Stop after — don't auto-chain into re-verification (see fix-verify-changes' own rules on this).

2. **Otherwise, is the user asking for a fresh review** ("review my changes", "verify staged changes", "check this before I commit")?
   → Run **verify-changes** (which itself auto-runs `changes-summary` first if missing/stale — don't run `changes-summary` separately here, that'd be redundant).
   → Present the resulting `verify-changes-notes.md` contents to the user and stop. Wait for their answers before touching `fix-verify-changes` — this is a hard stop, not a suggestion.

3. **Is the user asking only for a summary, not a review** ("what did I change", "summarize staged changes")?
   → Run **changes-summary** only. Don't escalate to a full review unless asked.

4. **Is there no staged diff at all?**
   → Say so plainly, don't run anything.

## Rules

- Never skip straight to `fix-verify-changes` without an existing `verify-changes-notes.md` — there's nothing to fix against. If the user asks for fixes with no notes file present, run the full review first (step 2), then stop and ask, per that skill's normal flow.
- Never auto-run the full three-skill chain in one shot. Blocking questions exist specifically so the user weighs in before code changes happen — collapsing the pipeline defeats that.
- If ambiguous which step the user means, ask one short clarifying question rather than guessing which sub-skill to run.
