# AGENTS.md

Repo-level instructions for AI coding agents (Cursor, Codex, Copilot, Antigravity, etc).

## Code review workflow

For anything involving reviewing, verifying, or checking staged changes before commit,
use the **review-agent** skill (`skills/review-agent/SKILL.md`) as the entry point —
it decides whether to summarize, review, or apply fixes based on current repo state.
Don't invoke the sub-skills (`changes-summary`, `verify-changes`, `fix-verify-changes`)
directly unless explicitly named.

## Other conventions

<!-- Add project-wide conventions here, e.g.: -->
<!-- - Design system: see DESIGN_THEME.md -->
<!-- - Stack: SolidStart + MongoDB -->
<!-- - Skill files live in /skills, one folder per skill -->
