---
name: fix-verify-changes
description: Apply fixes based on verify-changes-notes.md — takes the user's answers to blocking questions plus approval of suggested fixes, then implements them and updates the notes file. Use whenever the user answers questions from a prior verify-changes review, or asks to apply/resolve the suggested fixes.
---

# Fix Verify Changes

Takes the user's input (answers to blocking questions, and/or approval of suggested fixes) and implements the corresponding code changes, then marks items resolved.

## Preconditions

- `verify-changes-notes.md` must exist. If it doesn't, tell the user to run **verify-changes** first — don't guess at what needs fixing.

## Steps

1. Read `verify-changes-notes.md`.
2. Match the user's input to open items:
   - Answers to "Needs Answer" questions → use the answer to resolve the ambiguity, then implement the corresponding code change based on that answer.
   - Approval/go-ahead on "Suggested Fixes" → implement those directly (they were already scoped to be actionable without more input).
   - If the user only answers some items, only act on those — don't silently apply unrelated suggested fixes unless they said "apply all" or similar.
3. Make the code changes.
4. Update `verify-changes-notes.md`: check off (`- [x]`) each resolved item, and append a one-line note of what was done next to it.
5. If any answer reveals a *new* concern (e.g. the answer implies another edge case), add it as a new "Needs Answer" or "Suggested Fixes" item rather than silently handling it — keep the notes file as the single source of truth for what's open vs resolved.

## Rules

- Don't touch items the user hasn't addressed yet.
- Don't re-run the full verify-changes review automatically after fixing — that's a separate, explicit step if the user wants re-verification (run **verify-changes** again; it'll detect the diff changed via the diff-id check and refresh both files).
- Keep code changes scoped to what the notes item describes — don't use this as an opportunity for unrelated refactors.
