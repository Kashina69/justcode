---
name: verify-changes
description: Perform a senior-software-engineer-style code review of staged changes — check business logic clarity, conventions, and completeness, then write blocking questions and non-blocking suggestions to verify-changes-notes.md. Use whenever the user asks to review, verify, or check their staged changes before committing. Automatically ensures changes-summary.md exists and is current first.
---

# Verify Changes

Reviews staged changes like a senior engineer doing a PR review: flags ambiguous business logic, convention violations, and gaps, then separates findings into things that need a human answer versus things that can just be fixed.

## Step 0: Ensure changes-summary.md is current

1. Compute the current staged-diff id: `git diff --staged | git hash-object --stdin` (first 8 chars).
2. If `changes-summary.md` doesn't exist, or its `<!-- diff-id: ... -->` header doesn't match the current id, run the **changes-summary** skill first to regenerate it.
3. Read `changes-summary.md`.

## Step 1: Review

Read the full staged diff (`git diff --staged`) alongside the summary. Evaluate like a senior reviewer:

- **Business logic**: Is intent clear? Any place where the "why" is guessable but not certain — flag as a question rather than assuming.
- **Conventions**: Does this match the project's existing patterns (naming, structure, error handling, file organization)? Check against any DESIGN_THEME.md, style guide, or established convention in the repo if present.
- **Completeness**: Missing tests, missing error handling, missing edge cases, leftover debug code/comments, TODOs.
- **Scope**: Does the diff do one coherent thing, or should it be split?

## Step 2: Write verify-changes-notes.md

Overwrite `verify-changes-notes.md` in the project root:

```
<!-- diff-id: <same 8-char-hash as changes-summary.md> -->
## Overall assessment
<1-2 lines: ready to commit / needs input / needs fixes>

## Needs Answer (blocking)
- [ ] <question about business logic/intent that fix-verify-changes cannot resolve alone>

## Suggested Fixes (non-blocking)
- [ ] <convention/cleanup/completeness item fix-verify-changes can apply directly>
```

- Only include a "Needs Answer" item if it genuinely blocks correctness or intent — not "did you mean to do X" for obviously fine code. Ask only what a reasonable senior reviewer would actually ask before approving.
- "Suggested Fixes" should be concrete enough to act on without more context (e.g. "add null check on `user.email` in auth.ts:42", not "improve error handling").
- Keep each line short. This file is meant to be read by the user and then fed to fix-verify-changes.

## Step 3: Report to the user

Print the same content conversationally so the user isn't forced to open the file — but the file is the source of truth for the fix-verify-changes skill.
