---
name: changes-summary
description: Summarize currently staged git changes into a changes-summary.md file at the project root. Use whenever the user asks to summarize staged changes, review what's staged, or wants a plain-language changelog of what's about to be committed. Also triggered automatically by the verify-changes skill when it needs a fresh summary.
---

# Changes Summary

Produces a short, human-readable summary of staged git changes and writes it to `changes-summary.md` in the project root (overwriting any previous version).

## Steps

1. Run `git diff --staged` to get the full diff. Run `git status --staged` (or `git diff --staged --name-status`) for the file list.
2. If there are no staged changes, write a one-line note to `changes-summary.md` saying so and stop.
3. Compute a short hash/id for the current staged diff (e.g. `git diff --staged | git hash-object --stdin`, first 8 chars). This is used later by verify-changes to detect staleness.
4. Write `changes-summary.md` using the template below, overwriting the file.

## Output template

```
<!-- diff-id: <8-char-hash> -->
## Summary
- What: <1 line, what changed overall>
- Why: <1 line, best-guess intent from the diff/commit context — flag if unclear>
- How: <1 line, the general approach/mechanism>

## Details
- <file path>: what changed, why, how — 1 line, combine trivial files into one bullet (e.g. "3 files reformatted, no logic change")
```

## Rules

- Bullets only, no prose paragraphs.
- Skip line-by-line detail for whitespace/formatting-only diffs — just note the file count.
- Total output under 200 words.
- Never guess at business intent with false confidence — if "why" isn't inferable from the diff, say "unclear from diff" rather than fabricating a reason. This flag matters downstream: verify-changes turns it into a question for the user.
